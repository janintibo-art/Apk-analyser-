package com.example.apkanalyzer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.apkanalyzer.databinding.ActivityDetailBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private var analysis: ApkToolkit.ApkAnalysis? = null
    private var paths: List<String> = emptyList()
    private var deep: ApkToolkit.DeepInspect? = null
    private var deepLoading = false

    companion object {
        private const val EXTRA_PATH = "path"
        private const val EXTRA_SPLITS = "splits"
        fun start(context: Context, primaryPath: String, splits: ArrayList<String> = arrayListOf()) {
            context.startActivity(
                Intent(context, DetailActivity::class.java).apply {
                    putExtra(EXTRA_PATH, primaryPath)
                    putStringArrayListExtra(EXTRA_SPLITS, splits)
                }
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path == null) {
            finish()
            return
        }
        val splits = intent.getStringArrayListExtra(EXTRA_SPLITS) ?: arrayListOf()
        paths = listOf(path) + splits
        analyze(path)
    }

    private fun analyze(primary: String) {
        binding.content.text = getString(R.string.analyzing)
        lifecycleScope.launch {
            val a = withContext(Dispatchers.IO) {
                ApkToolkit.analyzeApk(this@DetailActivity, primary, paths)
            }
            analysis = a
            if (a == null) {
                binding.content.text = getString(R.string.analyze_fail)
                return@launch
            }
            title = a.label
            binding.content.text = render(a)
            invalidateOptionsMenu()
        }
    }

    private fun size(bytes: Long): String = Formatter.formatShortFileSize(this, bytes)

    private fun ouiNon(b: Boolean): String = if (b) "oui" else "non"

    private fun render(a: ApkToolkit.ApkAnalysis): CharSequence {
        val sb = StringBuilder()
        fun line(s: String = "") = sb.appendLine(s)

        line("📦 ${a.label}")
        line(a.packageName)
        line()

        line("ℹ️ GÉNÉRAL")
        line("  Version : ${a.versionName} (code ${a.versionCode})")
        line("  SDK : min ${a.minSdk} · cible ${a.targetSdk}")
        line("  Taille du fichier : ${size(a.fileSizeBytes)}")
        line("  Architectures : " +
            if (a.abis.isEmpty()) "aucune (pas de code natif)" else a.abis.joinToString(", "))
        line("  SHA-256 : ${a.fileSha256}")
        line()

        a.installInfo?.let { ii ->
            line("🏷️ INSTALLATION")
            line("  Installée le : ${ii.firstInstall}")
            line("  Mise à jour : ${ii.lastUpdate}")
            line("  Source : ${ii.installer ?: "inconnue (hors store)"}")
            line()
        }

        line("🚩 DRAPEAUX")
        line("  Debuggable : ${ouiNon(a.flags.debuggable)}${if (a.flags.debuggable) "  ⚠️" else ""}")
        line("  Sauvegarde autorisée : ${ouiNon(a.flags.allowBackup)}")
        line("  Trafic en clair (HTTP) : ${ouiNon(a.flags.cleartextTraffic)}" +
            if (a.flags.cleartextTraffic) "  ⚠️" else "")
        if (a.flags.testOnly) line("  testOnly : oui")
        if (a.flags.largeHeap) line("  largeHeap : oui")
        line()

        val dangerCount = a.permissions.count { it.dangerous }
        line("🔐 PERMISSIONS (${a.permissions.size}) — $dangerCount sensible(s)")
        if (a.permissions.isEmpty()) line("  (aucune)")
        a.permissions.forEach {
            val mark = if (it.dangerous) "⚠️" else "•"
            line("  $mark ${it.label} (${it.name.substringAfterLast('.')})")
        }
        line()

        line("🧩 COMPOSANTS")
        fun compLine(label: String, list: List<ApkToolkit.Comp>) {
            val exp = list.count { it.exported }
            val unguarded = list.count { it.exported && !it.guarded }
            line("  $label : ${list.size}  (exportés : $exp, sans protection : $unguarded)")
        }
        compLine("Activities", a.components.activities)
        compLine("Services", a.components.services)
        compLine("Receivers", a.components.receivers)
        compLine("Providers", a.components.providers)
        val exposed = (a.components.activities + a.components.services +
            a.components.receivers + a.components.providers)
            .filter { it.exported && !it.guarded }
        if (exposed.isNotEmpty()) {
            line("  ⚠️ Exportés sans permission :")
            exposed.take(12).forEach { line("    - ${it.name}") }
            if (exposed.size > 12) line("    … +${exposed.size - 12} autres")
        }
        line()

        line("🔑 SIGNATURE")
        val schemes = buildList {
            if (a.schemeV1) add("v1")
            if (a.schemeV2Plus) add("v2/v3")
        }
        line("  Schémas détectés : ${if (schemes.isEmpty()) "inconnu" else schemes.joinToString(", ")}")
        if (a.signers.isEmpty()) line("  (aucun certificat)")
        a.signers.forEachIndexed { i, c ->
            if (a.signers.size > 1) line("  — Signataire ${i + 1} —")
            line("  Sujet : ${c.subject}")
            line("  Émetteur : ${c.issuer}")
            line("  Validité : ${c.notBefore} → ${c.notAfter}")
            line("  N° série : ${c.serial}")
            line("  SHA-256 : ${c.sha256}")
            line("  SHA-1 : ${c.sha1}")
            line("  MD5 : ${c.md5}")
        }
        line()

        line("🗂️ CONTENU DE L'APK")
        line("  Entrées : ${a.fileTree.totalEntries} · décompressé : ${size(a.fileTree.totalUncompressed)}")
        line("  Par catégorie :")
        a.fileTree.groups.forEach { line("    ${it.first} : ${size(it.second)}") }
        line("  Plus gros fichiers :")
        a.fileTree.largest.forEach { line("    ${size(it.second)}  —  ${it.first}") }

        if (deepLoading || deep != null) {
            line()
            line("🔬 INSPECTION AVANCÉE")
            if (deepLoading) {
                line("  Analyse du code en cours…")
            } else deep?.let { d ->
                line("  Fichiers dex : ${d.dexCount}")
                line("  Méthodes (références) : ${"%,d".format(d.methodCount)}")
                line("  Classes : ${"%,d".format(d.classCount)}")
                line("  Trackers détectés (${d.trackers.size}) :")
                if (d.trackers.isEmpty()) line("    aucun")
                d.trackers.forEach { line("    • $it") }
                val plus = if (d.urls.size >= 300) "+" else ""
                line("  URLs trouvées (${d.urls.size}$plus, aperçu) :")
                if (d.urls.isEmpty()) line("    aucune")
                d.urls.take(30).forEach { line("    $it") }
                if (d.urls.size > 30) line("    … +${d.urls.size - 30} autres")
            }
        }

        return sb.toString()
    }

    // ───────────────────────────── Menu / actions ─────────────────────────────

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.detail_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val ready = analysis != null
        menu.findItem(R.id.action_deep)?.isVisible = ready
        menu.findItem(R.id.action_search_apk)?.isVisible = ready
        menu.findItem(R.id.action_export)?.isVisible = ready
        menu.findItem(R.id.action_copy_all)?.isVisible = ready
        menu.findItem(R.id.action_copy_sha256)?.isVisible = ready
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_deep -> { runDeep(); true }
            R.id.action_search_apk -> { searchApk(); true }
            R.id.export_txt -> { export("txt"); true }
            R.id.export_json -> { export("json"); true }
            R.id.export_html -> { export("html"); true }
            R.id.action_copy_all -> {
                analysis?.let { copy("Analyse", Exporter.text(it), R.string.copied_all) }
                true
            }
            R.id.action_copy_sha256 -> {
                analysis?.let { copy("SHA-256", it.fileSha256, R.string.sha256_copied) }
                true
            }
            android.R.id.home -> { finish(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun runDeep() {
        val a = analysis ?: return
        if (deepLoading) return
        deepLoading = true
        binding.content.text = render(a)
        lifecycleScope.launch {
            val d = withContext(Dispatchers.IO) {
                ApkToolkit.deepInspect(this@DetailActivity, paths)
            }
            deep = d
            deepLoading = false
            binding.content.text = render(a)
        }
    }

    private fun searchApk() {
        if (analysis == null) return
        val input = EditText(this).apply { hint = getString(R.string.search_apk_hint) }
        AlertDialog.Builder(this)
            .setTitle(R.string.search_apk)
            .setView(input)
            .setPositiveButton(R.string.search_apk) { _, _ ->
                val q = input.text.toString()
                if (q.isNotEmpty()) doSearch(q)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun doSearch(q: String) {
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { ApkToolkit.searchInApk(paths, q) }
            val msg = if (r.matchingEntries.isEmpty()) getString(R.string.search_none)
            else r.matchingEntries.joinToString("\n") + (if (r.truncated) "\n…" else "")
            AlertDialog.Builder(this@DetailActivity)
                .setTitle(getString(R.string.search_result, r.query, r.matchingEntries.size))
                .setMessage(msg)
                .setPositiveButton(android.R.string.ok, null)
                .show()
        }
    }

    private fun export(format: String) {
        val a = analysis ?: return
        val content: String
        val mime: String
        when (format) {
            "json" -> { content = Exporter.json(a); mime = "application/json" }
            "html" -> { content = Exporter.html(a); mime = "text/html" }
            else -> { content = Exporter.text(a); mime = "text/plain" }
        }
        val name = "${a.packageName}_analyse.$format"
        val tree = Prefs.treeUri(this)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                ApkToolkit.saveText(this@DetailActivity, name, mime, content, tree)
            }
            val dest = if (tree != null) getString(R.string.dest_custom)
            else getString(R.string.dest_downloads)
            val msg = if (ok) getString(R.string.export_ok, format.uppercase(), dest)
            else getString(R.string.export_fail)
            Toast.makeText(this@DetailActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun copy(label: String, value: String, msgRes: Int) {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText(label, value))
        Toast.makeText(this, getString(msgRes), Toast.LENGTH_SHORT).show()
    }
}
