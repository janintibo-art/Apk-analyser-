package com.example.apkanalyzer

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.text.format.Formatter
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.apkanalyzer.databinding.ItemAppBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppAdapter(
    private val onClick: (ApkToolkit.InstalledApp) -> Unit,
    private val onOverflow: (ApkToolkit.InstalledApp, View) -> Unit,
    private val onLongClick: (ApkToolkit.InstalledApp) -> Unit,
    private val onToggleSelect: (ApkToolkit.InstalledApp) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private val items = mutableListOf<ApkToolkit.InstalledApp>()
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    var selectionMode = false
    val selected = linkedSetOf<String>()
    var favorites: Set<String> = emptySet()
    private var selColor: Int? = null

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<ApkToolkit.InstalledApp>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        val ctx = holder.itemView.context
        holder.b.icon.setImageDrawable(app.icon)
        holder.b.name.text = app.label
        holder.b.pkg.text = app.packageName
        val version = app.versionName ?: "?"
        val size = Formatter.formatShortFileSize(ctx, app.sizeBytes)
        val date = dateFmt.format(Date(app.lastUpdate))
        holder.b.meta.text = "v$version · $size · MAJ $date"
        holder.b.star.visibility = if (app.packageName in favorites) View.VISIBLE else View.GONE

        val isSel = selected.contains(app.packageName)
        holder.b.overflow.visibility = if (selectionMode) View.GONE else View.VISIBLE
        holder.b.select.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.b.select.isChecked = isSel
        holder.b.root.setBackgroundColor(if (isSel) selectionColor(ctx) else Color.TRANSPARENT)

        holder.b.root.setOnClickListener {
            if (selectionMode) onToggleSelect(app) else onClick(app)
        }
        holder.b.root.setOnLongClickListener {
            onLongClick(app)
            true
        }
        holder.b.overflow.setOnClickListener { onOverflow(app, it) }
    }

    override fun getItemCount() = items.size

    private fun selectionColor(ctx: Context): Int {
        selColor?.let { return it }
        val tv = TypedValue()
        ctx.theme.resolveAttribute(
            com.google.android.material.R.attr.colorSecondaryContainer, tv, true
        )
        return tv.data.also { selColor = it }
    }
}
