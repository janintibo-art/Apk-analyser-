package com.example.apkanalyzer

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private const val NAME = "prefs"
    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    // ── Dossier de sortie ──
    fun treeUri(c: Context): Uri? = sp(c).getString("tree", null)?.let { Uri.parse(it) }
    fun setTreeUri(c: Context, uri: Uri?) {
        sp(c).edit().putString("tree", uri?.toString()).apply()
    }

    // ── Favoris ──
    fun favorites(c: Context): MutableSet<String> =
        (sp(c).getStringSet("favs", emptySet()) ?: emptySet()).toMutableSet()

    fun isFavorite(c: Context, pkg: String): Boolean = favorites(c).contains(pkg)

    /** Bascule l'état favori, renvoie true si désormais favori. */
    fun toggleFavorite(c: Context, pkg: String): Boolean {
        val set = favorites(c)
        val nowFav: Boolean
        if (set.contains(pkg)) {
            set.remove(pkg); nowFav = false
        } else {
            set.add(pkg); nowFav = true
        }
        sp(c).edit().putStringSet("favs", set).apply()
        return nowFav
    }

    // ── Historique d'extraction ──
    data class HistoryEntry(val pkg: String, val count: Int, val time: Long)

    fun addHistory(c: Context, pkg: String, count: Int) {
        val old = try {
            JSONArray(sp(c).getString("hist", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val newArr = JSONArray()
        newArr.put(
            JSONObject()
                .put("pkg", pkg)
                .put("count", count)
                .put("time", System.currentTimeMillis())
        )
        var i = 0
        while (i < old.length() && newArr.length() < 50) {
            newArr.put(old.get(i)); i++
        }
        sp(c).edit().putString("hist", newArr.toString()).apply()
    }

    fun history(c: Context): List<HistoryEntry> {
        val arr = try {
            JSONArray(sp(c).getString("hist", "[]"))
        } catch (e: Exception) {
            return emptyList()
        }
        return (0 until arr.length()).mapNotNull {
            val o = arr.optJSONObject(it) ?: return@mapNotNull null
            HistoryEntry(o.optString("pkg"), o.optInt("count"), o.optLong("time"))
        }
    }

    fun clearHistory(c: Context) {
        sp(c).edit().remove("hist").apply()
    }
}
