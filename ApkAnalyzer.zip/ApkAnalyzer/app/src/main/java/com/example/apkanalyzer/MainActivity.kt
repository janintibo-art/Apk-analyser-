package com.example.apkanalyzer

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.view.ActionMode
import androidx.appcompat.widget.SearchView
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.apkanalyzer.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AppAdapter

    private var allApps: List<ApkToolkit.InstalledApp> = emptyList()
    private var displayed: List<ApkToolkit.InstalledApp> = emptyList()
    private var query: String = ""
    private var showSystem: Boolean = false
    private var favOnly: Boolean = false

    private enum class SortMode { NAME, DATE, SIZE }
    private var sortMode: SortMode = SortMode.NAME

    private var actionMode: ActionMode? = null

    private val pickApk = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val path = ApkToolkit.copyUriToCache(this, uri)
            if (path != null) DetailActivity.start(this, path)
            else Toast.makeText(this, R.string.error_read_file, Toast.LENGTH_SHORT).show()
        }
    }

    private val pickTree = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                // ignore
            }
            Prefs.setTreeUri(this, uri)
            Toast.makeText(this, R.string.folder_set, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = AppAdapter(
            onClick = { app -> DetailActivity.start(this, app.apkPath, ArrayList(app.splitPaths)) },
            onOverflow = { app, anchor -> showActions(app, anchor) },
            onLongClick = { app -> if (adapter.selectionMode) toggleSelection(app) else startSelection(app) },
            onToggleSelect = { app -> toggleSelection(app) }
        )
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        loadApps()
    }

    private fun loadApps() {
        binding.progress.visibility = View.VISIBLE
        binding.empty.visibility = View.GONE
        lifecycleScope.launch {
            val apps = withContext(Dispatchers.IO) {
                ApkToolkit.listInstalledApps(this@MainActivity, includeSystem = showSystem)
            }
            allApps = apps
            binding.progress.visibility = View.GONE
            refreshDisplay()
        }
    }

    private fun refreshDisplay() {
        val favs = Prefs.favorites(this)
        adapter.favorites = favs
        var list = allApps
        if (favOnly) list = list.filter { it.packageName in favs }
        val q = query.trim().lowercase()
        if (q.isNotEmpty()) list = list.filter {
            it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
        list = when (sortMode) {
            SortMode.NAME -> list.sortedBy { it.label.lowercase() }
            SortMode.DATE -> list.sortedByDescending { it.lastUpdate }
            SortMode.SIZE -> list.sortedByDescending { it.sizeBytes }
        }
        list = list.sortedByDescending { it.packageName in favs }
        displayed = list
        adapter.submit(list)
        binding.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    // ─────────────────────────── Multi-sélection ─────────────────────────────

    private fun startSelection(app: ApkToolkit.InstalledApp) {
        adapter.selectionMode = true
        adapter.selected.clear()
        adapter.selected.add(app.packageName)
        adapter.notifyDataSetChanged()
        actionMode = startSupportActionMode(actionModeCallback)
        updateSelectionTitle()
    }

    private fun toggleSelection(app: ApkToolkit.InstalledApp) {
        if (!adapter.selected.add(app.packageName)) adapter.selected.remove(app.packageName)
        adapter.notifyDataSetChanged()
        if (adapter.selected.isEmpty()) actionMode?.finish() else updateSelectionTitle()
    }

    private fun selectAllDisplayed() {
        adapter.selected.addAll(displayed.map { it.packageName })
        adapter.notifyDataSetChanged()
        updateSelectionTitle()
    }

    private fun updateSelectionTitle() {
        actionMode?.title = getString(R.string.sel_title, adapter.selected.size)
    }

    private val actionModeCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            mode.menuInflater.inflate(R.menu.selection_menu, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            return when (item.itemId) {
                R.id.action_extract_selected -> { extractSelected(); true }
                R.id.action_select_all -> { selectAllDisplayed(); true }
                else -> false
            }
        }

        override fun onDestroyActionMode(mode: ActionMode) {
            adapter.selectionMode = false
            adapter.selected.clear()
            adapter.notifyDataSetChanged()
            actionMode = null
        }
    }

    private fun extractSelected() {
        val pkgs = adapter.selected.toList()
        val tree = Prefs.treeUri(this)
        lifecycleScope.launch {
            val total = withContext(Dispatchers.IO) {
                var sum = 0
                for (p in pkgs) {
                    val app = allApps.find { it.packageName == p } ?: continue
                    val n = ApkToolkit.extractApk(this@MainActivity, app, tree)
                    if (n > 0) {
                        sum += n
                        Prefs.addHistory(this@MainActivity, p, n)
                    }
                }
                sum
            }
            val msg = if (total > 0) getString(R.string.extract_ok, total, destLabel())
            else getString(R.string.extract_fail)
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
            actionMode?.finish()
        }
    }

    // ───────────────────────── Actions sur une app ───────────────────────────

    private fun showActions(app: ApkToolkit.InstalledApp, anchor: View) {
        val isFav = Prefs.isFavorite(this, app.packageName)
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, getString(R.string.act_analyze))
        popup.menu.add(0, 2, 1, getString(if (isFav) R.string.unfav else R.string.fav))
        popup.menu.add(0, 3, 2, getString(R.string.act_extract))
        popup.menu.add(0, 4, 3, getString(R.string.act_bundle))
        popup.menu.add(0, 5, 4, getString(R.string.act_share))
        popup.menu.add(0, 6, 5, getString(R.string.act_launch))
        popup.menu.add(0, 7, 6, getString(R.string.act_settings))
        popup.menu.add(0, 8, 7, getString(R.string.act_store))
        popup.menu.add(0, 9, 8, getString(R.string.act_uninstall))
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> DetailActivity.start(this, app.apkPath, ArrayList(app.splitPaths))
                2 -> toggleFavorite(app)
                3 -> extract(app)
                4 -> bundle(app)
                5 -> share(app)
                6 -> launchApp(app.packageName)
                7 -> openSettings(app.packageName)
                8 -> openStore(app.packageName)
                9 -> uninstall(app.packageName)
            }
            true
        }
        popup.show()
    }

    private fun toggleFavorite(app: ApkToolkit.InstalledApp) {
        val nowFav = Prefs.toggleFavorite(this, app.packageName)
        Toast.makeText(
            this,
            if (nowFav) R.string.fav_added else R.string.fav_removed,
            Toast.LENGTH_SHORT
        ).show()
        refreshDisplay()
    }

    private fun extract(app: ApkToolkit.InstalledApp) {
        val tree = Prefs.treeUri(this)
        lifecycleScope.launch {
            val count = withContext(Dispatchers.IO) {
                ApkToolkit.extractApk(this@MainActivity, app, tree)
            }
            if (count > 0) Prefs.addHistory(this@MainActivity, app.packageName, count)
            val msg = if (count > 0) getString(R.string.extract_ok, count, destLabel())
            else getString(R.string.extract_fail)
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun bundle(app: ApkToolkit.InstalledApp) {
        val tree = Prefs.treeUri(this)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                ApkToolkit.extractBundle(this@MainActivity, app, tree)
            }
            if (ok) Prefs.addHistory(this@MainActivity, app.packageName, 1)
            val msg = if (ok) getString(R.string.bundle_ok, destLabel())
            else getString(R.string.bundle_fail)
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun share(app: ApkToolkit.InstalledApp) {
        lifecycleScope.launch {
            val uris = withContext(Dispatchers.IO) {
                ApkToolkit.prepareShareUris(this@MainActivity, app)
            }
            if (uris.isEmpty()) {
                Toast.makeText(this@MainActivity, R.string.share_fail, Toast.LENGTH_SHORT).show()
                return@launch
            }
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    putExtra(Intent.EXTRA_STREAM, uris[0])
                    type = "application/vnd.android.package-archive"
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                    type = "application/vnd.android.package-archive"
                }
            }
            val clip = ClipData.newRawUri("apk", uris[0])
            for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
            intent.clipData = clip
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, getString(R.string.act_share)))
        }
    }

    private fun launchApp(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, R.string.no_launch, Toast.LENGTH_SHORT).show()
    }

    private fun openSettings(pkg: String) {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        )
    }

    private fun openStore(pkg: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$pkg")
                )
            )
        }
    }

    private fun uninstall(pkg: String) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }

    // ───────────────────────────── Historique ────────────────────────────────

    private fun showHistory() {
        val hist = Prefs.history(this)
        if (hist.isEmpty()) {
            Toast.makeText(this, R.string.history_empty, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = allApps.associate { it.packageName to it.label }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val items = hist.map { e ->
            val name = labels[e.pkg] ?: e.pkg
            "$name\n${fmt.format(Date(e.time))} · ${e.count} fichier(s)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.history)
            .setItems(items) { _, which ->
                val pkg = hist[which].pkg
                allApps.find { it.packageName == pkg }?.let {
                    DetailActivity.start(this, it.apkPath, ArrayList(it.splitPaths))
                }
            }
            .setNeutralButton(R.string.clear_history) { _, _ -> Prefs.clearHistory(this) }
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    // ─────────────────────────────── Langue ──────────────────────────────────

    private fun setLocale(tag: String) {
        val locales = if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
        else LocaleListCompat.forLanguageTags(tag)
        AppCompatDelegate.setApplicationLocales(locales)
    }

    // ───────────────────────── Préférences (dossier) ─────────────────────────

    private fun destLabel(): String =
        if (Prefs.treeUri(this) != null) getString(R.string.dest_custom)
        else getString(R.string.dest_downloads)

    // ──────────────────── Menu : recherche, tri, options ──────────────────────

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)

        val searchView = menu.findItem(R.id.action_search).actionView as? SearchView
        searchView?.queryHint = getString(R.string.search_hint)
        searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                query = newText ?: ""
                refreshDisplay()
                return true
            }
        })

        menu.findItem(R.id.action_show_system).isChecked = showSystem
        menu.findItem(R.id.action_favorites_only).isChecked = favOnly
        val current = when (sortMode) {
            SortMode.NAME -> R.id.sort_name
            SortMode.DATE -> R.id.sort_date
            SortMode.SIZE -> R.id.sort_size
        }
        menu.findItem(current).isChecked = true
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.sort_name -> { sortMode = SortMode.NAME; item.isChecked = true; refreshDisplay() }
            R.id.sort_date -> { sortMode = SortMode.DATE; item.isChecked = true; refreshDisplay() }
            R.id.sort_size -> { sortMode = SortMode.SIZE; item.isChecked = true; refreshDisplay() }
            R.id.action_show_system -> {
                showSystem = !showSystem
                item.isChecked = showSystem
                loadApps()
            }
            R.id.action_favorites_only -> {
                favOnly = !favOnly
                item.isChecked = favOnly
                refreshDisplay()
            }
            R.id.action_history -> showHistory()
            R.id.output_choose -> pickTree.launch(null)
            R.id.output_default -> {
                Prefs.setTreeUri(this, null)
                Toast.makeText(this, R.string.folder_default, Toast.LENGTH_SHORT).show()
            }
            R.id.lang_system -> setLocale("")
            R.id.lang_fr -> setLocale("fr")
            R.id.lang_en -> setLocale("en")
            R.id.action_analyze_file -> pickApk.launch(arrayOf("*/*"))
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
