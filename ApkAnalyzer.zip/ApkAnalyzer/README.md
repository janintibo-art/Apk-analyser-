# APK Analyzer

Application Android pour **lister, extraire, partager et analyser en profondeur** les APK
des applications installées — ainsi que n'importe quel fichier `.apk` importé.

## Fonctionnalités

### Liste des applications
- Liste avec icône, nom, package, version, taille (base + splits) et date de mise à jour
- Recherche par nom ou package, tri (nom / date / taille), affichage des apps système
- Favoris (étoile, remontés en tête) et filtre « favoris uniquement »
- Historique des extractions

### Actions sur une application
- Analyser, lancer, ouvrir dans les réglages, voir sur le Play Store, désinstaller
- Extraire l'APK (base + splits), extraire en **archive unique `.apks`**, **partager** l'APK
- Dossier de destination au choix (sélecteur Android) ou Téléchargements par défaut
- Multi-sélection (appui long) pour extraire plusieurs apps d'un coup

### Analyse d'un APK
- Version, SDK min/cible, taille, architectures natives, **SHA-256** du fichier
- Dates et source d'installation
- Drapeaux : debuggable, allowBackup, trafic en clair…
- Permissions en clair, avec les **dangereuses/sensibles** mises en évidence
- Composants (activities/services/receivers/providers) et **exportés sans protection**
- Signature : schémas v1/v2-v3, certificats (sujet, émetteur, validité, MD5/SHA-1/SHA-256)
- Contenu de l'APK par catégorie et plus gros fichiers
- **Inspection avancée** : comptage des méthodes/classes dex, **détection heuristique de
  trackers / SDK publicitaires**, et extraction des **URLs** embarquées
- **Recherche** d'un texte dans l'APK (noms d'entrées + contenu)
- Export du rapport en **TXT / JSON / HTML** et copie dans le presse-papiers

### Confort
- Material You (couleurs dynamiques sur Android 12+)
- Bascule de langue **Français / English** (mémorisée)

## Compiler l'APK sur GitHub (sans Android Studio)

1. Crée un dépôt sur GitHub et pousse ce dossier (branche `main`).
2. Onglet **Actions** → le workflow *Build APK* se lance (ou via **Run workflow**).
3. À la fin (✔), ouvre le run → **Artifacts** → télécharge **app-debug-apk** :
   il contient `app-debug.apk`, signé en debug, directement installable.

## Compiler en local (optionnel)

Ouvrir le dossier dans **Android Studio** (il télécharge Gradle et le SDK tout seul),
puis *Run* ▶. En ligne de commande, si Gradle est installé : `gradle wrapper` puis
`./gradlew assembleDebug`.

## Notes techniques

- **`QUERY_ALL_PACKAGES`** : nécessaire depuis Android 11 pour voir les autres apps.
  Sans souci pour un APK installé manuellement ; à justifier seulement sur le Play Store.
- **`minSdk 29`** (Android 10) : extraction sans permission de stockage (MediaStore / SAF).
- La détection de trackers est **heuristique** (par préfixe de package dans le dex) :
  elle peut manquer des SDK obfusqués ou en signaler à tort. À titre indicatif.
- Réinstaller un app bundle exige tous les fichiers extraits (base + splits), d'où l'archive `.apks`.
- Les fichiers extraits/exports vont dans **Download/ApkExtractor/** (ou le dossier choisi).
